// ============================================================
// Siachen Mark — Report Generator
// Generates HTML & JSON reports for businesses
// ============================================================

function generateHTMLReport(business, audit) {
  const scoreColor = audit.totalScore >= 80 ? '#10B981' : audit.totalScore >= 60 ? '#F59E0B' : '#EF4444';
  const gradeColor = audit.grade ? audit.grade.color : '#6B7280';

  const issuesHTML = audit.issues.map(i => `
    <div class="issue-item severity-${i.severity}">
      <span class="issue-icon">${i.severity === 'critical' ? '🔴' : i.severity === 'high' ? '🟠' : '🟡'}</span>
      <div>
        <strong>${i.category}</strong>
        <p>${i.message}</p>
      </div>
    </div>`).join('');

  const warningsHTML = audit.warnings.map(w => `
    <div class="warning-item">
      <span>⚠️</span>
      <div><strong>${w.category}</strong><p>${w.message}</p></div>
    </div>`).join('');

  const passedHTML = audit.passed.map(p => `
    <div class="passed-item"><span>✅</span><p>${p}</p></div>`).join('');

  const scoresHTML = Object.entries(audit.scores).map(([key, s]) => {
    const pct = Math.round((s.earned / s.max) * 100);
    const color = pct >= 80 ? '#10B981' : pct >= 50 ? '#F59E0B' : '#EF4444';
    return `
      <div class="score-row">
        <span class="score-name">${s.name}</span>
        <div class="score-bar-wrap">
          <div class="score-bar" style="width:${pct}%;background:${color}"></div>
        </div>
        <span class="score-pts">${s.earned}/${s.max}</span>
      </div>`;
  }).join('');

  const rankingHTML = audit.rankingFactors.map(rf => {
    const statusColor = rf.status === 'Strong' || rf.status === 'Set' || rf.status === 'Complete' || rf.status === 'Active' || rf.status === 'Linked' || rf.status === 'Good'
      ? '#10B981' : rf.status === 'Moderate' ? '#F59E0B' : '#EF4444';
    return `
      <tr>
        <td>${rf.factor}</td>
        <td><span class="badge" style="background:${statusColor}20;color:${statusColor}">${rf.status}</span></td>
        <td><span class="imp-badge">${rf.importance}</span></td>
        <td class="tip-cell">${rf.tip}</td>
      </tr>`;
  }).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>GBP Audit Report — ${audit.businessName}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', sans-serif; background: #0A1628; color: #E2E8F0; }
  .header { background: linear-gradient(135deg, #0A1628 0%, #1B2E4B 100%); padding: 40px; border-bottom: 1px solid #2563EB33; }
  .logo { font-size: 13px; color: #3B82F6; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 12px; }
  .biz-name { font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 8px; }
  .biz-meta { font-size: 14px; color: #94A3B8; }
  .score-hero { display: flex; align-items: center; gap: 30px; margin-top: 24px; }
  .score-circle { width: 100px; height: 100px; border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; border: 4px solid ${scoreColor}; }
  .score-num { font-size: 32px; font-weight: 800; color: ${scoreColor}; }
  .score-max { font-size: 12px; color: #64748B; }
  .grade-box { padding: 8px 20px; border-radius: 8px; background: ${gradeColor}20; border: 1px solid ${gradeColor}; }
  .grade-letter { font-size: 36px; font-weight: 800; color: ${gradeColor}; }
  .grade-label { font-size: 13px; color: ${gradeColor}; }
  .content { max-width: 1000px; margin: 0 auto; padding: 30px 40px; }
  .section { background: #1B2E4B; border-radius: 12px; padding: 24px; margin-bottom: 24px; border: 1px solid #2563EB22; }
  .section-title { font-size: 16px; font-weight: 700; color: #3B82F6; margin-bottom: 16px; text-transform: uppercase; letter-spacing: 1px; }
  .info-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 12px; }
  .info-item { background: #0A1628; border-radius: 8px; padding: 12px; }
  .info-label { font-size: 11px; color: #64748B; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px; }
  .info-value { font-size: 14px; color: #E2E8F0; font-weight: 500; }
  .score-row { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
  .score-name { width: 180px; font-size: 13px; color: #CBD5E1; flex-shrink: 0; }
  .score-bar-wrap { flex: 1; height: 8px; background: #0A1628; border-radius: 4px; overflow: hidden; }
  .score-bar { height: 100%; border-radius: 4px; transition: width 0.5s ease; }
  .score-pts { width: 50px; text-align: right; font-size: 13px; font-weight: 600; color: #94A3B8; }
  .issue-item, .warning-item, .passed-item { display: flex; gap: 12px; padding: 12px; border-radius: 8px; margin-bottom: 8px; align-items: flex-start; }
  .severity-critical { background: #EF444415; border: 1px solid #EF444440; }
  .severity-high { background: #F97316 15; border: 1px solid #F9731640; }
  .severity-medium { background: #F59E0B15; border: 1px solid #F59E0B40; }
  .warning-item { background: #F59E0B10; border: 1px solid #F59E0B30; }
  .passed-item { background: #10B98110; border: 1px solid #10B98130; }
  .issue-item strong, .warning-item strong { font-size: 13px; color: #E2E8F0; }
  .issue-item p, .warning-item p, .passed-item p { font-size: 12px; color: #94A3B8; margin-top: 2px; }
  table { width: 100%; border-collapse: collapse; }
  th { text-align: left; font-size: 11px; color: #64748B; text-transform: uppercase; letter-spacing: 1px; padding: 8px 12px; border-bottom: 1px solid #2563EB22; }
  td { padding: 10px 12px; font-size: 13px; color: #CBD5E1; border-bottom: 1px solid #0A162880; }
  .badge { padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
  .imp-badge { font-size: 11px; color: #64748B; }
  .tip-cell { font-size: 12px; color: #94A3B8; }
  .footer { text-align: center; padding: 30px; color: #475569; font-size: 12px; border-top: 1px solid #2563EB22; }
  @media print { body { background: white; color: black; } }
</style>
</head>
<body>
<div class="header" style="max-width:1000px;margin:0 auto;">
  <div class="logo">🏔 Siachen Mark — GBP Audit Report</div>
  <div class="biz-name">${audit.businessName}</div>
  <div class="biz-meta">
    ${business.primaryCategory ? `📍 ${business.primaryCategory}` : ''}
    ${business.address ? ` &nbsp;|&nbsp; ${business.address}` : ''}
    &nbsp;|&nbsp; Audited: ${new Date(audit.auditDate).toLocaleString()}
    ${audit.position ? ` &nbsp;|&nbsp; Position: #${audit.position}` : ''}
  </div>
  <div class="score-hero">
    <div class="score-circle">
      <span class="score-num">${audit.totalScore}</span>
      <span class="score-max">/100</span>
    </div>
    <div class="grade-box">
      <div class="grade-letter">${audit.grade.letter}</div>
      <div class="grade-label">${audit.grade.label}</div>
    </div>
    <div>
      <div style="font-size:14px;color:#94A3B8;">GBP Health Score</div>
      <div style="font-size:13px;color:#64748B;margin-top:6px;">
        🔴 ${audit.issues.length} Issues &nbsp;
        ⚠️ ${audit.warnings.length} Warnings &nbsp;
        ✅ ${audit.passed.length} Passed
      </div>
    </div>
  </div>
</div>

<div class="content">

  <div class="section">
    <div class="section-title">📊 Category Scores Breakdown</div>
    ${scoresHTML}
  </div>

  <div class="section">
    <div class="section-title">📋 Business Information</div>
    <div class="info-grid">
      <div class="info-item"><div class="info-label">Business Name</div><div class="info-value">${business.name || '—'}</div></div>
      <div class="info-item"><div class="info-label">Rating</div><div class="info-value">★ ${business.rating || '—'} (${business.reviewCount || 0} reviews)</div></div>
      <div class="info-item"><div class="info-label">Primary Category</div><div class="info-value">${business.primaryCategory || '—'}</div></div>
      <div class="info-item"><div class="info-label">Phone</div><div class="info-value">${business.phone || '—'}</div></div>
      <div class="info-item"><div class="info-label">Website</div><div class="info-value">${business.website || '—'}</div></div>
      <div class="info-item"><div class="info-label">Address</div><div class="info-value">${business.address || '—'}</div></div>
      <div class="info-item"><div class="info-label">Photos</div><div class="info-value">${business.photoCount || 0} photos</div></div>
      <div class="info-item"><div class="info-label">Business Hours</div><div class="info-value">${business.hasHours ? 'Set ✅' : 'Not set ❌'}</div></div>
      <div class="info-item"><div class="info-label">Google Posts</div><div class="info-value">${business.hasPosts ? 'Active ✅' : 'None ❌'}</div></div>
      <div class="info-item"><div class="info-label">Q&A Section</div><div class="info-value">${business.hasQA ? 'Active ✅' : 'Empty ❌'}</div></div>
    </div>
  </div>

  ${audit.issues.length > 0 ? `
  <div class="section">
    <div class="section-title">🔴 Critical Issues (${audit.issues.length})</div>
    ${issuesHTML}
  </div>` : ''}

  ${audit.warnings.length > 0 ? `
  <div class="section">
    <div class="section-title">⚠️ Warnings (${audit.warnings.length})</div>
    ${warningsHTML}
  </div>` : ''}

  ${audit.passed.length > 0 ? `
  <div class="section">
    <div class="section-title">✅ Passed Checks (${audit.passed.length})</div>
    ${passedHTML}
  </div>` : ''}

  <div class="section">
    <div class="section-title">📈 Local Ranking Factors</div>
    <table>
      <thead><tr><th>Factor</th><th>Status</th><th>Importance</th><th>Recommendation</th></tr></thead>
      <tbody>${rankingHTML}</tbody>
    </table>
  </div>

</div>

<div class="footer">
  Generated by Siachen Mark GBP Auditor &nbsp;|&nbsp; siachenmark.com &nbsp;|&nbsp; ${new Date().toLocaleDateString()}
</div>
</body>
</html>`;
}

function generateJSONReport(business, audit) {
  return {
    tool: 'Siachen Mark GBP Auditor',
    version: '1.0.0',
    generatedAt: new Date().toISOString(),
    business: {
      name: business.name,
      rating: business.rating,
      reviewCount: business.reviewCount,
      primaryCategory: business.primaryCategory,
      address: business.address,
      phone: business.phone,
      website: business.website,
      photoCount: business.photoCount,
      hasHours: business.hasHours,
      hasPosts: business.hasPosts,
      hasQA: business.hasQA,
      description: business.description,
      url: business.url,
      position: business.position
    },
    audit: {
      totalScore: audit.totalScore,
      maxScore: audit.maxScore,
      grade: audit.grade,
      categoryScores: audit.scores,
      issues: audit.issues,
      warnings: audit.warnings,
      passed: audit.passed,
      rankingFactors: audit.rankingFactors
    }
  };
}

function sanitizeFilename(name) {
  return name.replace(/[^a-z0-9]/gi, '_').toLowerCase().substring(0, 40);
}
