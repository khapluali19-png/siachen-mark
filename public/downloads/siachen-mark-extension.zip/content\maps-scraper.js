// ============================================================
// Siachen Mark — Google Maps Content Script v2.3
// Reliable Business Profile Opening & Automatic Return-to-Results Batch Flow
// ============================================================

(function () {
  'use strict';

  if (window.__siachenMarkInjected) return;
  window.__siachenMarkInjected = true;

  let cachedBasicList = [];

  // ── Listen for messages from sidebar/popup ───────────────
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
      switch (message.action) {
        
        // ── 1. GET_BUSINESS_LIST (Returns basic cards quickly) ──
        case 'GET_BUSINESS_LIST': {
          try {
            const limit = message.limit || 10;
            const businesses = await getBusinessList(limit);
            cachedBasicList = businesses;
            sendResponse({ success: true, count: businesses.length, businesses });
          } catch (err) {
            sendResponse({ success: false, error: err.message, businesses: [] });
          }
          break;
        }

        // ── 2. EXTRACT_SINGLE_BUSINESS (Itemized extraction) ──
        case 'EXTRACT_SINGLE_BUSINESS': {
          const index = message.index;
          try {
            const result = await extractSingleBusiness(index);
            sendResponse(result);
          } catch (err) {
            sendResponse({
              success: false,
              index,
              error: 'EXTRACTION_ERROR',
              message: err.message,
              businessData: null,
            });
          }
          break;
        }

        // ── 3. RETURN_TO_RESULTS (Restores search results feed) ──
        case 'RETURN_TO_RESULTS': {
          try {
            const result = await returnToSearchResults(5000);
            sendResponse(result);
          } catch (err) {
            sendResponse({
              success: false,
              error: 'RETURN_TO_RESULTS_FAILED',
              message: err.message,
            });
          }
          break;
        }

        // ── Legacy PING check ──────────────────────────────
        case 'PING':
          sendResponse({ pong: true, url: window.location.href });
          break;

        default:
          sendResponse({ error: 'Unknown action: ' + message.action });
      }
    })();
    return true; // Keep message channel open for async response
  });

  // ═══════════════════════════════════════════════════════════
  // STEP 1: GET BUSINESS LIST (Fast metadata extraction)
  // ═══════════════════════════════════════════════════════════
  async function getBusinessList(limit) {
    const feed = await waitForAny(['[role="feed"]', '[role="main"] .m6QErb', '.DxyBCb'], 5000);
    if (!feed) return [];

    await sleep(400);
    const cards = collectResultCards();
    const toProcess = cards.slice(0, limit);

    const list = [];
    for (let i = 0; i < toProcess.length; i++) {
      const basic = extractBasicFromCard(toProcess[i], i + 1);
      if (basic.name) {
        list.push({ index: i, ...basic });
      }
    }
    return list;
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 2: EXTRACT SINGLE BUSINESS (Profile open + details)
  // ═══════════════════════════════════════════════════════════
  async function extractSingleBusiness(index) {
    const basic = cachedBasicList[index] || null;

    // Re-query live card using name/index matching instead of stale index alone
    let card = findLiveCardForBusiness(index, basic);

    if (!card) {
      return {
        success: false,
        index,
        error: 'CARD_NOT_FOUND',
        message: `Card for "${basic?.name || 'Index ' + index}" could not be located in live DOM.`,
        businessData: null,
      };
    }

    // Step A: Open business profile in-place
    const openResult = await openBusinessProfile(card, basic?.name);
    if (!openResult.success) {
      return {
        success: false,
        index,
        error: openResult.error || 'PROFILE_NOT_OPENED',
        message: `Could not open full business profile for "${basic?.name || 'Index ' + index}".`,
        businessData: null,
      };
    }

    // Step B: Scrape open details panel
    const detail = await scrapeOpenBusinessPanel();

    if (!detail.name && !basic?.name) {
      return {
        success: false,
        index,
        error: 'EMPTY_PROFILE_DATA',
        message: 'Opened business profile panel contained no valid header data.',
        businessData: null,
      };
    }

    // Merge basic metadata with full detail panel data
    const mergedData = mergeData(basic || extractBasicFromCard(card, index + 1), detail);

    return {
      success: true,
      index,
      businessDataReady: true,
      businessData: mergedData,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 3: RELIABLE RETURN TO SEARCH RESULTS
  // ═══════════════════════════════════════════════════════════
  async function returnToSearchResults(timeout = 5000) {
    // Check if feed is already visible and active
    const feed = document.querySelector('[role="feed"]');
    if (feed && feed.isConnected && feed.children.length > 0) {
      const style = window.getComputedStyle(feed);
      if (style.display !== 'none' && style.visibility !== 'hidden') {
        return { success: true };
      }
    }

    // Find Google Maps SPA back/close button
    const backBtn = document.querySelector(
      'button[aria-label*="Back" i], button[jsaction*="pane.back"], button[jsaction*="back"], button[aria-label*="Close" i], button.hVZn8e'
    );

    if (backBtn && backBtn.isConnected) {
      try {
        const opts = { bubbles: true, cancelable: true, view: window, which: 1, button: 0 };
        backBtn.dispatchEvent(new PointerEvent('pointerdown', opts));
        backBtn.dispatchEvent(new MouseEvent('mousedown', opts));
        backBtn.dispatchEvent(new PointerEvent('pointerup', opts));
        backBtn.dispatchEvent(new MouseEvent('mouseup', opts));
        backBtn.dispatchEvent(new MouseEvent('click', opts));
      } catch (e) {
        backBtn.click();
      }
    } else {
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    }

    // Wait for search feed container to reappear
    const restoredFeed = await waitForAny(['[role="feed"]', '[role="main"] .m6QErb', '.DxyBCb'], timeout);
    if (!restoredFeed) {
      return { success: false, error: 'RETURN_TO_RESULTS_FAILED', message: 'Could not restore Google Maps search results feed.' };
    }

    await sleep(400); // Allow DOM settlement
    return { success: true };
  }

  // Find live connected card matching expected business name or index
  function findLiveCardForBusiness(index, basicInfo) {
    const cards = collectResultCards();
    if (cards.length === 0) return null;

    // Check direct index match
    const cardAtIndex = cards[index];
    if (cardAtIndex && cardAtIndex.isConnected) {
      if (!basicInfo || !basicInfo.name) return cardAtIndex;
      const cardName = extractBasicFromCard(cardAtIndex).name;
      const targetKey = basicInfo.name.split(' ')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
      const cardKey = cardName.split(' ')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
      if (cardKey === targetKey || cardName.toLowerCase().includes(targetKey)) {
        return cardAtIndex;
      }
    }

    // Search live DOM cards by business name keyword match
    if (basicInfo && basicInfo.name) {
      const targetKey = basicInfo.name.split(' ')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
      for (const card of cards) {
        if (card && card.isConnected) {
          const cardName = extractBasicFromCard(card).name;
          const cardKey = cardName.split(' ')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
          if (cardKey === targetKey || (targetKey.length >= 3 && cardName.toLowerCase().includes(targetKey))) {
            return card;
          }
        }
      }
    }

    // Fallback to cardAtIndex if connected
    if (cardAtIndex && cardAtIndex.isConnected) return cardAtIndex;

    return null;
  }

  // ═══════════════════════════════════════════════════════════
  // RELIABLE BUSINESS PROFILE OPENING & DETECTION
  // Triggers natural human click event chain matching Google Maps SPA jsaction
  // ═══════════════════════════════════════════════════════════
  async function openBusinessProfile(card, expectedName) {
    if (!card || !card.isConnected) {
      return { success: false, error: 'CARD_DETACHED' };
    }

    const target = card.querySelector('.hfpxzc') ||
                   card.querySelector('.qBF1Pd, [class*="fontHeadline"], h3') ||
                   card.querySelector('a[href*="maps/place"]') ||
                   card;

    if (!target) {
      return { success: false, error: 'TARGET_NOT_FOUND' };
    }

    try {
      const opts = { bubbles: true, cancelable: true, view: window, which: 1, button: 0 };
      target.dispatchEvent(new PointerEvent('pointerdown', opts));
      target.dispatchEvent(new MouseEvent('mousedown', opts));
      target.dispatchEvent(new PointerEvent('pointerup', opts));
      target.dispatchEvent(new MouseEvent('mouseup', opts));
      target.dispatchEvent(new MouseEvent('click', opts));
    } catch (e) {
      target.click();
    }

    const verified = await verifyBusinessProfileOpened(expectedName, 4500);
    if (!verified) {
      return { success: false, error: 'PROFILE_NOT_OPENED' };
    }

    return { success: true, businessDataReady: true };
  }

  async function verifyBusinessProfileOpened(expectedName, timeout = 4500) {
    const startTime = Date.now();
    const keyword = expectedName ? expectedName.split(' ')[0].toLowerCase().replace(/[^a-z0-9]/g, '') : '';

    while (Date.now() - startTime < timeout) {
      const h1 = document.querySelector('h1.DUwDvf, h1[class*="fontDisplay"], .lMbq3e h1, h1[class*="fontHeadline"]');
      const h1Text = h1 ? h1.textContent.trim() : '';

      if (h1Text.length > 0) {
        if (keyword) {
          const currentLower = h1Text.toLowerCase().replace(/[^a-z0-9]/g, '');
          if (currentLower.includes(keyword) || keyword.includes(currentLower.substring(0, 5))) {
            return true;
          }
        } else {
          return true;
        }
      }

      const hasIndicators = !!(
        document.querySelector('[data-item-id="address"]') ||
        document.querySelector('[data-item-id*="phone"]') ||
        document.querySelector('[data-item-id="authority"]') ||
        document.querySelector('[aria-label*="reviews" i]') ||
        document.querySelector('.F7nice') ||
        document.querySelector('.PYvSYb')
      );

      if (h1Text.length > 0 && hasIndicators) {
        return true;
      }

      await sleep(250);
    }

    return false;
  }

  // ═══════════════════════════════════════════════════════════
  // DOM EXTRACTION HELPERS & SELECTORS
  // ═══════════════════════════════════════════════════════════

  function collectResultCards() {
    const feed = document.querySelector('[role="feed"]');
    if (feed) {
      const feedCards = Array.from(feed.children).filter(el =>
        el.querySelector('a[href*="maps/place"]') ||
        el.querySelector('[class*="fontHeadline"]') ||
        el.querySelector('.qBF1Pd')
      );
      if (feedCards.length > 0) return feedCards;
    }

    const nv2Cards = document.querySelectorAll('.Nv2PK');
    if (nv2Cards.length > 0) return Array.from(nv2Cards);

    const placeLinks = document.querySelectorAll('a[href*="maps/place"]');
    if (placeLinks.length > 0) {
      const seen = new Set();
      const cards = [];
      placeLinks.forEach(link => {
        const card = link.closest('[jsaction], .lI9IFe, .m6QErb > div') || link.parentElement?.parentElement;
        if (card && !seen.has(card)) {
          seen.add(card);
          cards.push(card);
        }
      });
      if (cards.length > 0) return cards;
    }

    return [];
  }

  function extractBasicFromCard(card, position) {
    const name = getText(card, ['.qBF1Pd', '.fontHeadlineSmall', '[class*="fontHeadline"]', 'h3', 'a[href*="maps/place"] span']);
    const ratingRaw = getText(card, ['.MW4etd', '[class*="rating"]', '.yi40Hd']);
    const rating = parseFloat(ratingRaw) || null;
    const reviewRaw = getText(card, ['.UY7F9', '[class*="review"]', '.Ls7mNc']);
    const reviewCount = parseInt(reviewRaw.replace(/[^0-9]/g, '')) || 0;
    const category = getText(card, ['.W4Etje', '.fontBodyMedium span:first-child', '[class*="subtype"]', '.DkEaL']);
    const address = getText(card, ['.W4Etje:nth-child(2)', '.fontBodyMedium span:nth-child(2)', '[class*="address"]']);
    const linkEl = card.querySelector('a[href*="maps/place"]');
    const url = linkEl ? linkEl.href : window.location.href;
    const placeId = extractPlaceIdFromUrl(url);

    return { name, rating, reviewCount, primaryCategory: category, address, url, placeId, position };
  }

  async function scrapeOpenBusinessPanel() {
    await waitForAny(['h1.DUwDvf', 'h1[class*="fontDisplay"]', '.lMbq3e h1', '[data-section-id]'], 4000);
    await sleep(400);

    const name = getText(document, ['h1.DUwDvf', 'h1[class*="fontDisplay"]', '.lMbq3e h1', 'h1[class*="fontHeadline"]']);
    
    const ratingRaw = (() => {
      const el = document.querySelector('[aria-label*="stars"], [aria-label*="rating"]');
      if (el) {
        const m = el.getAttribute('aria-label').match(/(\d+\.?\d*)/);
        if (m) return m[1];
      }
      return getText(document, ['.F7nice span[aria-hidden="true"]', '.ceNzKf span:first-child', '[class*="fontDisplayLarge"]']);
    })();
    const rating = parseFloat(ratingRaw) || null;

    const reviewRaw = (() => {
      const el = document.querySelector('[aria-label*="reviews"], [aria-label*="Reviews"]');
      if (el) {
        const m = el.getAttribute('aria-label').match(/([\d,]+)\s*review/i);
        if (m) return m[1];
      }
      const btn = document.querySelector('button[aria-label*="review"], .F7nice button');
      if (btn) return btn.textContent;
      return getText(document, ['.F7nice .fontBodySmall', '.UY7F9']);
    })();
    const reviewCount = parseInt(reviewRaw.replace(/[^0-9]/g, '')) || 0;

    const primaryCategory = (() => {
      const catBtn = document.querySelector('button.DkEaL, [jsaction*="category"] .fontBodyMedium');
      if (catBtn) return catBtn.textContent.trim();
      return getText(document, ['.DkEaL', 'button[jsaction*="pane.rating.category"]']);
    })();

    const secondaryCategories = (() => {
      const cats = document.querySelectorAll('[aria-label*="Search for"] button, button[jsaction*="category"]');
      const results = [];
      cats.forEach(c => {
        const t = c.textContent.trim();
        if (t && t !== primaryCategory && t.length < 60) results.push(t);
      });
      return results.slice(0, 5);
    })();

    const address = (() => {
      const el = document.querySelector('[data-item-id="address"] .Io6YTe, [data-item-id="address"] .fontBodyMedium');
      if (el) return el.textContent.trim();
      const btn = document.querySelector('button[data-item-id="address"]');
      if (btn) return btn.querySelector('.Io6YTe, .fontBodyMedium')?.textContent.trim() || '';
      return '';
    })();

    const phone = (() => {
      const el = document.querySelector('[data-item-id*="phone:tel"] .Io6YTe, a[href^="tel:"]');
      if (el) return el.tagName === 'A' ? el.href.replace('tel:', '') : el.textContent.trim();
      const btn = document.querySelector('button[data-item-id*="phone"]');
      if (btn) return btn.querySelector('.Io6YTe, .fontBodyMedium')?.textContent.trim() || '';
      return '';
    })();

    const website = (() => {
      const el = document.querySelector(
        'a[data-item-id="authority"], [data-item-id="authority"] a, a[aria-label*="website" i], a[aria-label*="Website"]'
      );
      return el ? (el.href || '').split('?')[0] : '';
    })();

    const businessStatus = (() => {
      const el = document.querySelector('[aria-label*="open" i], .o0Svhf, .MkUuGe');
      if (el) {
        const text = (el.getAttribute('aria-label') || el.textContent).toLowerCase();
        if (text.includes('permanently closed')) return 'PERMANENTLY_CLOSED';
        if (text.includes('temporarily closed')) return 'TEMPORARILY_CLOSED';
        if (text.includes('open')) return 'OPERATIONAL';
        if (text.includes('closed')) return 'CLOSED_NOW';
      }
      return 'UNKNOWN';
    })();

    const hours = {};
    let hasHours = false;
    (() => {
      const hoursContainer = document.querySelector('[aria-label*="hours" i] table, .y0skZc table');
      if (hoursContainer) {
        const rows = hoursContainer.querySelectorAll('tr');
        rows.forEach(row => {
          const cells = row.querySelectorAll('td, th');
          if (cells.length >= 2) {
            const day = cells[0].textContent.trim();
            const time = cells[1].textContent.trim().replace(/\s+/g, ' ');
            if (day && time && day.length < 15) {
              hours[day] = time;
              hasHours = true;
            }
          }
        });
      }
    })();

    const photoCount = (() => {
      const photoEl = document.querySelector('[aria-label*="photo" i]:not(input), button[aria-label*="photo" i]');
      if (photoEl) {
        const text = photoEl.getAttribute('aria-label') || photoEl.textContent || '';
        const m = text.match(/([\d,]+)\s*photo/i);
        if (m) return parseInt(m[1].replace(',', ''));
      }
      return 0;
    })();

    const ownerResponse = !!document.querySelector('[aria-label*="Owner" i], .GH0QDb');
    const hasPosts = !!document.querySelector('[aria-label*="post" i], [aria-label*="Update" i], .b3cB2');
    const hasQA = !!document.querySelector('[aria-label*="question" i], [aria-label*="Q&A" i], .M3ojUe');
    const description = getText(document, ['.PYvSYb', '[data-attrid="description"]', '.dbg0pd']);
    const coordinates = extractCoordinates();
    const placeId = extractPlaceIdFromUrl(window.location.href);

    return {
      name: name || undefined,
      rating,
      reviewCount,
      primaryCategory,
      secondaryCategories,
      address,
      phone,
      website,
      businessStatus,
      hours,
      hasHours,
      photoCount,
      ownerResponse,
      hasPosts,
      hasQA,
      description,
      coordinates,
      placeId,
      mapsUrl: window.location.href,
      scrapedAt: new Date().toISOString(),
    };
  }

  function getText(root, selectors) {
    for (const sel of selectors) {
      try {
        const el = root.querySelector ? root.querySelector(sel) : document.querySelector(sel);
        if (el) {
          const text = (el.getAttribute('aria-label') || el.textContent || '').trim();
          if (text) return text;
        }
      } catch (e) {}
    }
    return '';
  }

  function waitForAny(selectors, timeout = 5000) {
    return new Promise((resolve) => {
      for (const sel of selectors) {
        try {
          const el = document.querySelector(sel);
          if (el) { resolve(el); return; }
        } catch (e) {}
      }
      const observer = new MutationObserver(() => {
        for (const sel of selectors) {
          try {
            const el = document.querySelector(sel);
            if (el) { observer.disconnect(); clearTimeout(timer); resolve(el); return; }
          } catch (e) {}
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      const timer = setTimeout(() => { observer.disconnect(); resolve(null); }, timeout);
    });
  }

  function extractPlaceIdFromUrl(url) {
    try {
      const dataMatch = url.match(/!1s([^!]+)/);
      if (dataMatch) return decodeURIComponent(dataMatch[1]);
      const placeMatch = url.match(/place\/([^/]+)/);
      if (placeMatch) return decodeURIComponent(placeMatch[1]);
    } catch (e) {}
    return '';
  }

  function extractCoordinates() {
    try {
      const match = window.location.href.match(/@(-?\d+\.?\d*),(-?\d+\.?\d*),\d+/);
      if (match) return { lat: parseFloat(match[1]), lng: parseFloat(match[2]) };
    } catch (e) {}
    return null;
  }

  function mergeData(basic, detail) {
    return {
      name:               detail.name || basic?.name || 'Unknown Business',
      rating:             detail.rating ?? basic?.rating ?? null,
      reviewCount:        detail.reviewCount || basic?.reviewCount || 0,
      primaryCategory:    detail.primaryCategory || basic?.primaryCategory || '',
      secondaryCategories: detail.secondaryCategories || [],
      address:            detail.address || basic?.address || '',
      phone:              detail.phone || '',
      website:            detail.website || '',
      businessStatus:     detail.businessStatus || 'UNKNOWN',
      hours:              detail.hours || {},
      hasHours:           detail.hasHours || false,
      photoCount:         detail.photoCount || 0,
      ownerResponse:      detail.ownerResponse || false,
      hasPosts:           detail.hasPosts || false,
      hasQA:              detail.hasQA || false,
      description:        detail.description || '',
      coordinates:        detail.coordinates || null,
      placeId:            detail.placeId || basic?.placeId || '',
      mapsUrl:            detail.mapsUrl || basic?.url || '',
      url:                basic?.url || detail.mapsUrl || '',
      position:           basic?.position,
      scrapedAt:          detail.scrapedAt || new Date().toISOString(),
    };
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  console.log('[Siachen Mark] Content script v2.3 (Multi-Business Return & Live Card Selection) ready.');
})();
