// ============================================================
// Siachen Mark — GBP Audit Engine
// Scores businesses like GBP Everywhere — full audit
// ============================================================

/**
 * Main GBP Audit function
 * @param {Object} businessData - Raw scraped data
 * @returns {Object} - Full audit report with scores
 */
function runGBPAudit(businessData) {
  const audit = {
    businessName: businessData.name || 'Unknown Business',
    auditDate: new Date().toISOString(),
    position: businessData.position || null,
    url: businessData.url || '',
    placeId: businessData.placeId || '',
    categories: [],
    scores: {},
    issues: [],
    warnings: [],
    passed: [],
    totalScore: 0,
    maxScore: 100,
    grade: '',
    rankingFactors: [],
    rawData: businessData
  };

  let totalPoints = 0;

  // ── 1. Business Name (10 pts) ─────────────────────────────
  const nameScore = auditBusinessName(businessData, audit);
  audit.scores.name = nameScore;
  totalPoints += nameScore.earned;

  // ── 2. Categories (10 pts) ────────────────────────────────
  const categoryScore = auditCategories(businessData, audit);
  audit.scores.categories = categoryScore;
  totalPoints += categoryScore.earned;

  // ── 3. Business Description (5 pts) ──────────────────────
  const descScore = auditDescription(businessData, audit);
  audit.scores.description = descScore;
  totalPoints += descScore.earned;

  // ── 4. Contact Info — Phone (8 pts) ──────────────────────
  const phoneScore = auditPhone(businessData, audit);
  audit.scores.phone = phoneScore;
  totalPoints += phoneScore.earned;

  // ── 5. Website (7 pts) ───────────────────────────────────
  const websiteScore = auditWebsite(businessData, audit);
  audit.scores.website = websiteScore;
  totalPoints += websiteScore.earned;

  // ── 6. Address & Location (8 pts) ─────────────────────────
  const addressScore = auditAddress(businessData, audit);
  audit.scores.address = addressScore;
  totalPoints += addressScore.earned;

  // ── 7. Business Hours (10 pts) ────────────────────────────
  const hoursScore = auditHours(businessData, audit);
  audit.scores.hours = hoursScore;
  totalPoints += hoursScore.earned;

  // ── 8. Photos (15 pts) ────────────────────────────────────
  const photoScore = auditPhotos(businessData, audit);
  audit.scores.photos = photoScore;
  totalPoints += photoScore.earned;

  // ── 9. Reviews & Ratings (20 pts) ─────────────────────────
  const reviewScore = auditReviews(businessData, audit);
  audit.scores.reviews = reviewScore;
  totalPoints += reviewScore.earned;

  // ── 10. Google Posts (5 pts) ──────────────────────────────
  const postScore = auditPosts(businessData, audit);
  audit.scores.posts = postScore;
  totalPoints += postScore.earned;

  // ── 11. Q&A Section (2 pts) ──────────────────────────────
  const qaScore = auditQA(businessData, audit);
  audit.scores.qa = qaScore;
  totalPoints += qaScore.earned;

  // ── Calculate Total ───────────────────────────────────────
  audit.totalScore = Math.min(totalPoints, 100);
  audit.grade = getGrade(audit.totalScore);

  // ── Ranking Factors ───────────────────────────────────────
  audit.rankingFactors = generateRankingFactors(businessData, audit);

  return audit;
}

// ── Score: Business Name ─────────────────────────────────
function auditBusinessName(data, audit) {
  const score = { name: 'Business Name', max: 10, earned: 0, status: 'fail', details: [] };
  const name = data.name || '';

  if (!name) {
    audit.issues.push({ category: 'Business Name', severity: 'critical', message: 'Business name is missing from profile.' });
    return score;
  }

  score.earned += 5;
  score.details.push({ check: 'Name present', status: 'pass', value: name });

  // Check for keyword stuffing
  const wordCount = name.split(' ').length;
  const hasKeywordStuffing = wordCount > 5 && /[\|\-\–\(\)]/.test(name);
  if (hasKeywordStuffing) {
    audit.warnings.push({ category: 'Business Name', message: 'Possible keyword stuffing detected in business name. Google may penalize this.' });
    score.details.push({ check: 'No keyword stuffing', status: 'warning', value: 'Possible stuffing detected' });
  } else {
    score.earned += 3;
    score.details.push({ check: 'No keyword stuffing', status: 'pass', value: 'Name looks clean' });
  }

  // Check length
  if (name.length >= 3 && name.length <= 80) {
    score.earned += 2;
    score.details.push({ check: 'Name length optimal', status: 'pass', value: `${name.length} characters` });
    audit.passed.push('Business name is properly formatted');
  } else if (name.length > 80) {
    audit.warnings.push({ category: 'Business Name', message: 'Business name is too long (>80 chars). Trim it for better display.' });
    score.details.push({ check: 'Name length', status: 'warning', value: `${name.length} chars — too long` });
  }

  score.status = score.earned >= 7 ? 'pass' : score.earned >= 4 ? 'warning' : 'fail';
  return score;
}

// ── Score: Categories ────────────────────────────────────
function auditCategories(data, audit) {
  const score = { name: 'Business Categories', max: 10, earned: 0, status: 'fail', details: [] };
  const primary = data.primaryCategory || '';
  const secondary = data.secondaryCategories || [];

  if (!primary) {
    audit.issues.push({ category: 'Categories', severity: 'critical', message: 'No primary category set. This severely hurts local ranking.' });
    return score;
  }

  score.earned += 6;
  score.details.push({ check: 'Primary category', status: 'pass', value: primary });
  audit.passed.push(`Primary category: ${primary}`);

  if (secondary.length > 0) {
    score.earned += 4;
    score.details.push({ check: 'Secondary categories', status: 'pass', value: `${secondary.length} additional categories` });
    audit.passed.push(`${secondary.length} secondary categories added`);
  } else {
    audit.issues.push({ category: 'Categories', severity: 'medium', message: 'No secondary categories. Add relevant categories to appear in more searches.' });
    score.details.push({ check: 'Secondary categories', status: 'fail', value: 'None added' });
  }

  score.status = score.earned >= 8 ? 'pass' : score.earned >= 4 ? 'warning' : 'fail';
  return score;
}

// ── Score: Description ───────────────────────────────────
function auditDescription(data, audit) {
  const score = { name: 'Business Description', max: 5, earned: 0, status: 'fail', details: [] };
  const desc = data.description || '';

  if (!desc) {
    audit.issues.push({ category: 'Description', severity: 'medium', message: 'Business description is missing. Add a 750-char keyword-rich description.' });
    score.details.push({ check: 'Description present', status: 'fail', value: 'Missing' });
    return score;
  }

  score.earned += 2;
  score.details.push({ check: 'Description present', status: 'pass', value: `${desc.length} characters` });

  if (desc.length >= 200) {
    score.earned += 2;
    score.details.push({ check: 'Description length', status: 'pass', value: 'Good length (200+ chars)' });
  } else {
    audit.warnings.push({ category: 'Description', message: 'Description is too short. Aim for 250-750 characters with target keywords.' });
    score.details.push({ check: 'Description length', status: 'warning', value: `Only ${desc.length} chars — expand it` });
  }

  if (desc.length <= 750) {
    score.earned += 1;
    score.details.push({ check: 'Within limit', status: 'pass', value: 'Under 750 char limit' });
  }

  audit.passed.push('Business description is set');
  score.status = score.earned >= 4 ? 'pass' : score.earned >= 2 ? 'warning' : 'fail';
  return score;
}

// ── Score: Phone ─────────────────────────────────────────
function auditPhone(data, audit) {
  const score = { name: 'Phone Number', max: 8, earned: 0, status: 'fail', details: [] };
  const phone = data.phone || '';

  if (!phone) {
    audit.issues.push({ category: 'Phone', severity: 'critical', message: 'Phone number is missing. Customers cannot call — critical for local business.' });
    score.details.push({ check: 'Phone present', status: 'fail', value: 'Missing' });
    return score;
  }

  score.earned += 5;
  score.details.push({ check: 'Phone present', status: 'pass', value: phone });
  audit.passed.push(`Phone: ${phone}`);

  // Check if it looks valid (basic check)
  const cleaned = phone.replace(/[\s\-\(\)\+]/g, '');
  if (cleaned.length >= 10) {
    score.earned += 3;
    score.details.push({ check: 'Valid format', status: 'pass', value: 'Phone format looks valid' });
  } else {
    audit.warnings.push({ category: 'Phone', message: 'Phone number may be incomplete or incorrectly formatted.' });
    score.details.push({ check: 'Valid format', status: 'warning', value: 'Format may be incorrect' });
  }

  score.status = score.earned >= 6 ? 'pass' : 'warning';
  return score;
}

// ── Score: Website ───────────────────────────────────────
function auditWebsite(data, audit) {
  const score = { name: 'Website URL', max: 7, earned: 0, status: 'fail', details: [] };
  const website = data.website || '';

  if (!website) {
    audit.issues.push({ category: 'Website', severity: 'high', message: 'No website linked. Add your website URL to improve trust and ranking signals.' });
    score.details.push({ check: 'Website present', status: 'fail', value: 'Not linked' });
    return score;
  }

  score.earned += 5;
  score.details.push({ check: 'Website linked', status: 'pass', value: website });
  audit.passed.push(`Website: ${website}`);

  if (website.startsWith('https://')) {
    score.earned += 2;
    score.details.push({ check: 'HTTPS secure', status: 'pass', value: 'SSL secured website' });
    audit.passed.push('Website uses HTTPS (secure)');
  } else if (website.startsWith('http://')) {
    audit.warnings.push({ category: 'Website', message: 'Website uses HTTP (not secure). Switch to HTTPS for better trust signals.' });
    score.details.push({ check: 'HTTPS secure', status: 'warning', value: 'Not using HTTPS' });
  }

  score.status = score.earned >= 5 ? 'pass' : 'warning';
  return score;
}

// ── Score: Address ───────────────────────────────────────
function auditAddress(data, audit) {
  const score = { name: 'Address & Location', max: 8, earned: 0, status: 'fail', details: [] };
  const address = data.address || '';

  if (!address) {
    audit.issues.push({ category: 'Address', severity: 'critical', message: 'No address found. Businesses without addresses rank lower in local search.' });
    score.details.push({ check: 'Address present', status: 'fail', value: 'Missing' });
    return score;
  }

  score.earned += 4;
  score.details.push({ check: 'Address present', status: 'pass', value: address });
  audit.passed.push('Address is set');

  // Check address completeness (street + city at minimum)
  const parts = address.split(',').map(p => p.trim()).filter(p => p.length > 0);
  if (parts.length >= 3) {
    score.earned += 4;
    score.details.push({ check: 'Complete address', status: 'pass', value: `${parts.length} address components` });
    audit.passed.push('Address has full details (street, city, country)');
  } else if (parts.length >= 2) {
    score.earned += 2;
    audit.warnings.push({ category: 'Address', message: 'Address may be incomplete. Ensure street, city, and region are all present.' });
    score.details.push({ check: 'Complete address', status: 'warning', value: 'Partial address' });
  } else {
    audit.issues.push({ category: 'Address', severity: 'medium', message: 'Address appears incomplete. Add full street address with city and country.' });
    score.details.push({ check: 'Complete address', status: 'fail', value: 'Very incomplete' });
  }

  score.status = score.earned >= 6 ? 'pass' : score.earned >= 4 ? 'warning' : 'fail';
  return score;
}

// ── Score: Business Hours ────────────────────────────────
function auditHours(data, audit) {
  const score = { name: 'Business Hours', max: 10, earned: 0, status: 'fail', details: [] };
  const hours = data.hours || {};
  const hasHours = data.hasHours || false;

  if (!hasHours && Object.keys(hours).length === 0) {
    audit.issues.push({ category: 'Hours', severity: 'high', message: 'Business hours not set. Customers cannot see when you are open — hurts conversions.' });
    score.details.push({ check: 'Hours set', status: 'fail', value: 'Not configured' });
    return score;
  }

  score.earned += 6;
  score.details.push({ check: 'Hours set', status: 'pass', value: 'Opening hours configured' });
  audit.passed.push('Business hours are set');

  const daysSet = Object.keys(hours).length;
  if (daysSet >= 7) {
    score.earned += 4;
    score.details.push({ check: 'All days covered', status: 'pass', value: 'All 7 days have hours' });
    audit.passed.push('Hours set for all 7 days');
  } else if (daysSet >= 5) {
    score.earned += 2;
    audit.warnings.push({ category: 'Hours', message: `Only ${daysSet}/7 days have hours set. Add weekend hours if applicable.` });
    score.details.push({ check: 'All days covered', status: 'warning', value: `${daysSet}/7 days set` });
  } else {
    audit.issues.push({ category: 'Hours', severity: 'medium', message: 'Less than 5 days have hours. Set complete hours for all operating days.' });
    score.details.push({ check: 'All days covered', status: 'fail', value: `Only ${daysSet} days` });
  }

  score.status = score.earned >= 7 ? 'pass' : score.earned >= 4 ? 'warning' : 'fail';
  return score;
}

// ── Score: Photos ────────────────────────────────────────
function auditPhotos(data, audit) {
  const score = { name: 'Photos & Images', max: 15, earned: 0, status: 'fail', details: [] };
  const photoCount = data.photoCount || 0;

  if (photoCount === 0) {
    audit.issues.push({ category: 'Photos', severity: 'critical', message: 'No photos found! Businesses with photos get 42% more directions requests.' });
    score.details.push({ check: 'Photos present', status: 'fail', value: '0 photos' });
    return score;
  }

  score.details.push({ check: 'Photos present', status: 'pass', value: `${photoCount} photos found` });

  if (photoCount >= 1) score.earned += 3;
  if (photoCount >= 5) {
    score.earned += 3;
    score.details.push({ check: 'Minimum photos', status: 'pass', value: '5+ photos' });
  } else {
    audit.warnings.push({ category: 'Photos', message: 'Less than 5 photos. Add at least 10 photos (exterior, interior, products/services).' });
    score.details.push({ check: 'Minimum photos', status: 'warning', value: `Only ${photoCount} photos` });
  }

  if (photoCount >= 10) {
    score.earned += 4;
    score.details.push({ check: 'Good photo count', status: 'pass', value: '10+ photos — well done!' });
    audit.passed.push(`${photoCount} photos uploaded`);
  } else if (photoCount >= 5) {
    score.earned += 2;
    score.details.push({ check: 'Good photo count', status: 'warning', value: 'Add more photos (aim for 20+)' });
  }

  if (photoCount >= 20) {
    score.earned += 5;
    score.details.push({ check: 'Excellent photo count', status: 'pass', value: '20+ photos — excellent!' });
    audit.passed.push('Excellent photo count (20+)');
  } else if (photoCount >= 10) {
    score.earned += 2;
  }

  score.status = score.earned >= 10 ? 'pass' : score.earned >= 5 ? 'warning' : 'fail';
  return score;
}

// ── Score: Reviews ───────────────────────────────────────
function auditReviews(data, audit) {
  const score = { name: 'Reviews & Ratings', max: 20, earned: 0, status: 'fail', details: [] };
  const rating = parseFloat(data.rating) || 0;
  const reviewCount = parseInt(data.reviewCount) || 0;

  if (reviewCount === 0) {
    audit.issues.push({ category: 'Reviews', severity: 'critical', message: 'No reviews found! Reviews are the #1 ranking factor for local SEO. Get reviews immediately.' });
    score.details.push({ check: 'Reviews present', status: 'fail', value: '0 reviews' });
    return score;
  }

  // Review count scoring
  if (reviewCount >= 1) score.earned += 3;
  if (reviewCount >= 10) { score.earned += 2; score.details.push({ check: '10+ reviews', status: 'pass', value: `${reviewCount} total` }); }
  if (reviewCount >= 50) { score.earned += 2; score.details.push({ check: '50+ reviews', status: 'pass', value: 'Strong review count' }); }
  if (reviewCount >= 100) { score.earned += 3; score.details.push({ check: '100+ reviews', status: 'pass', value: 'Excellent review count!' }); audit.passed.push('100+ reviews — top tier'); }

  score.details.push({ check: 'Review count', status: reviewCount >= 10 ? 'pass' : 'warning', value: `${reviewCount} reviews` });

  if (reviewCount < 10) {
    audit.issues.push({ category: 'Reviews', severity: 'high', message: `Only ${reviewCount} reviews. Need at least 10 to compete. Send review request links to customers.` });
  }

  // Rating scoring
  if (rating >= 4.0) {
    score.earned += 5;
    score.details.push({ check: 'Rating 4.0+', status: 'pass', value: `★ ${rating}` });
    audit.passed.push(`Strong rating: ${rating} stars`);
  } else if (rating >= 3.5) {
    score.earned += 3;
    score.details.push({ check: 'Rating', status: 'warning', value: `★ ${rating} — improve to 4.0+` });
    audit.warnings.push({ category: 'Reviews', message: `Rating is ${rating}. Aim for 4.0+ to improve trust. Respond to negative reviews professionally.` });
  } else if (rating >= 3.0) {
    score.earned += 1;
    audit.issues.push({ category: 'Reviews', severity: 'high', message: `Low rating: ${rating} stars. Actively work on getting more 5-star reviews.` });
    score.details.push({ check: 'Rating', status: 'fail', value: `★ ${rating} — critical issue` });
  } else if (rating > 0) {
    audit.issues.push({ category: 'Reviews', severity: 'critical', message: `Very low rating: ${rating} stars. This severely hurts local ranking and conversions.` });
    score.details.push({ check: 'Rating', status: 'fail', value: `★ ${rating} — needs urgent attention` });
  }

  // Response rate estimate (if available)
  if (data.ownerResponse) {
    score.earned += 5;
    score.details.push({ check: 'Owner responses', status: 'pass', value: 'Owner is responding to reviews' });
    audit.passed.push('Owner is actively responding to reviews');
  } else {
    audit.warnings.push({ category: 'Reviews', message: 'No owner responses detected. Respond to every review (positive and negative) to show engagement.' });
    score.details.push({ check: 'Owner responses', status: 'warning', value: 'No responses found' });
  }

  score.status = score.earned >= 14 ? 'pass' : score.earned >= 8 ? 'warning' : 'fail';
  return score;
}

// ── Score: Google Posts ──────────────────────────────────
function auditPosts(data, audit) {
  const score = { name: 'Google Posts / Updates', max: 5, earned: 0, status: 'fail', details: [] };
  const hasPosts = data.hasPosts || false;

  if (!hasPosts) {
    audit.issues.push({ category: 'Google Posts', severity: 'medium', message: 'No Google Posts found. Post weekly updates, offers, events to boost engagement and visibility.' });
    score.details.push({ check: 'Posts active', status: 'fail', value: 'No posts found' });
    return score;
  }

  score.earned = 5;
  score.details.push({ check: 'Posts active', status: 'pass', value: 'Business is posting updates' });
  audit.passed.push('Google Posts are being used');
  score.status = 'pass';
  return score;
}

// ── Score: Q&A ───────────────────────────────────────────
function auditQA(data, audit) {
  const score = { name: 'Q&A Section', max: 2, earned: 0, status: 'fail', details: [] };
  const hasQA = data.hasQA || false;

  if (hasQA) {
    score.earned = 2;
    score.details.push({ check: 'Q&A present', status: 'pass', value: 'Q&A section is active' });
    audit.passed.push('Q&A section has content');
  } else {
    audit.warnings.push({ category: 'Q&A', message: 'No Q&A found. Add common questions and answers to improve profile completeness.' });
    score.details.push({ check: 'Q&A present', status: 'fail', value: 'Empty Q&A section' });
  }

  score.status = score.earned >= 2 ? 'pass' : 'fail';
  return score;
}

// ── Grade Calculator ─────────────────────────────────────
function getGrade(score) {
  if (score >= 90) return { letter: 'A+', label: 'Excellent', color: '#10B981' };
  if (score >= 80) return { letter: 'A', label: 'Very Good', color: '#34D399' };
  if (score >= 70) return { letter: 'B', label: 'Good', color: '#FBBF24' };
  if (score >= 60) return { letter: 'C', label: 'Average', color: '#F59E0B' };
  if (score >= 50) return { letter: 'D', label: 'Below Average', color: '#EF4444' };
  return { letter: 'F', label: 'Poor', color: '#DC2626' };
}

// ── Ranking Factors Analysis ─────────────────────────────
function generateRankingFactors(data, audit) {
  return [
    {
      factor: 'Profile Completeness',
      importance: 'High',
      status: audit.totalScore >= 80 ? 'Strong' : audit.totalScore >= 60 ? 'Moderate' : 'Weak',
      tip: audit.totalScore < 80 ? 'Complete all missing profile sections to boost ranking.' : 'Profile is well-optimized.'
    },
    {
      factor: 'Review Signals',
      importance: 'Very High',
      status: (parseFloat(data.rating) >= 4.0 && parseInt(data.reviewCount) >= 10) ? 'Strong' : 'Needs Work',
      tip: parseInt(data.reviewCount) < 10 ? 'Get more reviews — they are the #1 local ranking factor.' : 'Maintain review velocity with fresh reviews monthly.'
    },
    {
      factor: 'Category Relevance',
      importance: 'High',
      status: data.primaryCategory ? 'Set' : 'Missing',
      tip: data.primaryCategory ? 'Ensure primary category is the most specific match for your business.' : 'Set primary category immediately.'
    },
    {
      factor: 'NAP Consistency',
      importance: 'High',
      status: (data.phone && data.address) ? 'Present' : 'Incomplete',
      tip: 'Ensure Name, Address, Phone (NAP) matches exactly across all online directories.'
    },
    {
      factor: 'Photo Engagement',
      importance: 'Medium',
      status: (data.photoCount || 0) >= 10 ? 'Good' : 'Low',
      tip: (data.photoCount || 0) < 10 ? 'Add more photos — businesses with 100+ photos get 520% more calls.' : 'Keep adding fresh photos regularly.'
    },
    {
      factor: 'Content Freshness',
      importance: 'Medium',
      status: data.hasPosts ? 'Active' : 'Stale',
      tip: data.hasPosts ? 'Keep posting weekly to maintain freshness signals.' : 'Start posting weekly updates, offers, or events on Google.'
    },
    {
      factor: 'Website Authority',
      importance: 'Medium',
      status: data.website ? 'Linked' : 'Missing',
      tip: data.website ? 'Ensure your website is optimized with matching business info.' : 'Add your website to strengthen local signals.'
    },
    {
      factor: 'Business Hours',
      importance: 'Low',
      status: data.hasHours ? 'Complete' : 'Missing',
      tip: data.hasHours ? 'Add special/holiday hours to stay current.' : 'Set complete business hours for all days.'
    }
  ];
}

// Export for use in content script & sidebar
if (typeof module !== 'undefined') {
  module.exports = { runGBPAudit, getGrade };
}
