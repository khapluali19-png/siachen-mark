// ============================================================
// Siachen Mark — Popup Script v1.1 (API Auth)
// ============================================================
'use strict';

let currentUser = null;

document.addEventListener('DOMContentLoaded', async () => {
  await checkStatus();
});

async function checkStatus() {
  const res = await chrome.runtime.sendMessage({ action: 'GET_STATUS' });

  if (res.loggedIn && res.user) {
    currentUser = res.user;
    showLoggedIn(res.user);
  } else {
    showLoginForm();
  }
}

function showLoginForm() {
  document.getElementById('view-login').classList.remove('hidden');
  document.getElementById('view-status').classList.add('hidden');

  document.getElementById('btn-login').addEventListener('click', async () => {
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const msgEl = document.getElementById('login-msg');

    if (!email || !password) {
      msgEl.textContent = 'Please enter email and password.';
      msgEl.className = 'msg error';
      msgEl.classList.remove('hidden');
      return;
    }

    const btn = document.getElementById('btn-login');
    btn.textContent = 'Signing in…';
    btn.disabled = true;

    const res = await chrome.runtime.sendMessage({ action: 'LOGIN', email, password });

    if (res.success) {
      currentUser = res.user;
      showLoggedIn(res.user);
    } else {
      msgEl.textContent = '❌ ' + res.message;
      msgEl.className = 'msg error';
      msgEl.classList.remove('hidden');
      btn.textContent = 'Sign In';
      btn.disabled = false;
    }
  });

  document.getElementById('login-password').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') document.getElementById('btn-login').click();
  });
}

function showLoggedIn(user) {
  document.getElementById('view-login').classList.add('hidden');
  document.getElementById('view-status').classList.remove('hidden');

  const isUnlimited = user.plan === 'UNLIMITED';
  const remaining = isUnlimited ? '∞' : (user.remaining ?? Math.max(0, 10 - user.scanCount));

  document.getElementById('user-name').textContent = user.name || user.email;
  document.getElementById('user-email').textContent = user.email;
  document.getElementById('tier-display').textContent = isUnlimited ? '✨ Unlimited' : '🆓 Free';
  document.getElementById('tier-display').className = isUnlimited ? 'tier-val unlimited-col' : 'tier-val free-col';
  document.getElementById('stat-scans').textContent = user.scanCount || 0;
  document.getElementById('stat-remaining').textContent = remaining;

  if (remaining === 0 && !isUnlimited) {
    document.getElementById('limit-warning').classList.remove('hidden');
  }

  // Open sidebar button
  document.getElementById('btn-sidebar').addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab.url?.includes('google.com/maps')) {
      await chrome.tabs.update(tab.id, { url: 'https://www.google.com/maps' });
      await new Promise(r => setTimeout(r, 1500));
    }
    await chrome.sidePanel.open({ windowId: tab.windowId });
    window.close();
  });

  // Open Maps button
  document.getElementById('btn-maps').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.google.com/maps' });
    window.close();
  });

  // Open dashboard button
  document.getElementById('btn-dashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: 'http://localhost:3000/user' });
    window.close();
  });

  // Logout
  document.getElementById('btn-logout').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ action: 'LOGOUT' });
    showLoginForm();
  });
}
