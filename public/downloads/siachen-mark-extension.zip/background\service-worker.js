// ============================================================
// Siachen Mark GBP Auditor — Service Worker v2.0
// Fully connected to Siachen Mark backend API with complete message handlers
// ============================================================
'use strict';

const API_BASE = 'http://localhost:3000';
const FREE_LIMIT = 10;

// ─── On Install ───────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(['smToken', 'smUser', 'auditHistory']);
  if (!existing.smToken) {
    await chrome.storage.local.set({
      smToken: null,
      smUser: null,
      auditHistory: []
    });
  }
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
  console.log('[Siachen Mark] Service Worker v2.0 ready.');
});

// ─── Message Handler ──────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message.action) {

      // ── 1. LOGIN ──────────────────────────────────────────
      case 'LOGIN': {
        const { email, password } = message;
        try {
          const res = await fetch(`${API_BASE}/api/extension/auth`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
          });
          const data = await res.json();
          if (!res.ok) {
            sendResponse({ success: false, message: data.error || 'Login failed. Please check your credentials.' });
            return;
          }
          await chrome.storage.local.set({ smToken: data.token, smUser: data.user });
          sendResponse({ success: true, user: data.user });
        } catch (err) {
          sendResponse({ success: false, message: 'Cannot connect to Siachen Mark server at ' + API_BASE });
        }
        break;
      }

      // ── 2. LOGOUT ─────────────────────────────────────────
      case 'LOGOUT': {
        await chrome.storage.local.set({ smToken: null, smUser: null });
        sendResponse({ success: true });
        break;
      }

      // ── 3. GET_STATUS ─────────────────────────────────────
      case 'GET_STATUS': {
        const { smToken } = await chrome.storage.local.get(['smToken']);
        if (!smToken) {
          sendResponse({ loggedIn: false });
          return;
        }
        try {
          const res = await fetch(`${API_BASE}/api/extension/verify`, {
            headers: { 'Authorization': `Bearer ${smToken}` },
          });
          if (!res.ok) {
            await chrome.storage.local.set({ smToken: null, smUser: null });
            sendResponse({ loggedIn: false, reason: 'Token expired or invalid' });
            return;
          }
          const data = await res.json();
          await chrome.storage.local.set({ smUser: data.user });
          sendResponse({ loggedIn: true, user: data.user });
        } catch {
          // If offline/unreachable, return cached user state if available
          const { smUser } = await chrome.storage.local.get(['smUser']);
          if (smUser) {
            sendResponse({ loggedIn: true, user: smUser, offline: true });
          } else {
            sendResponse({ loggedIn: false, reason: 'Server unreachable' });
          }
        }
        break;
      }

      // ── 4. GET_LICENSE (Compatibility for Popup & Sidebar UI) ──
      case 'GET_LICENSE': {
        const { smUser } = await chrome.storage.local.get(['smUser']);
        if (!smUser) {
          sendResponse({ tier: 'free', usageCount: 0, daysLeft: 30 });
          return;
        }
        sendResponse({
          tier: smUser.plan === 'UNLIMITED' ? 'admin' : 'free',
          usageCount: smUser.scanCount || 0,
          daysLeft: 30,
        });
        break;
      }

      // ── 5. CHECK_LIMIT (Enforces plan limit before scan) ──
      case 'CHECK_LIMIT': {
        const { smToken, smUser } = await chrome.storage.local.get(['smToken', 'smUser']);
        if (!smToken) {
          sendResponse({ allowed: false, reason: 'not_logged_in', message: 'Please sign in to your Siachen Mark account first.' });
          return;
        }

        // Try fresh verify first
        try {
          const res = await fetch(`${API_BASE}/api/extension/verify`, {
            headers: { 'Authorization': `Bearer ${smToken}` },
          });
          if (res.ok) {
            const data = await res.json();
            await chrome.storage.local.set({ smUser: data.user });
            const user = data.user;
            if (user.plan === 'UNLIMITED') {
              sendResponse({ allowed: true, plan: 'UNLIMITED' });
              return;
            }
            if (user.scanCount < FREE_LIMIT) {
              sendResponse({ allowed: true, plan: 'FREE', remaining: FREE_LIMIT - user.scanCount });
              return;
            }
            sendResponse({ allowed: false, reason: 'limit_reached', message: 'Free limit reached (10/10 scans used).' });
            return;
          }
        } catch (e) { /* fallback to local check below */ }

        // Fallback to cached smUser
        if (smUser) {
          if (smUser.plan === 'UNLIMITED') {
            sendResponse({ allowed: true, plan: 'UNLIMITED' });
            return;
          }
          if ((smUser.scanCount || 0) < FREE_LIMIT) {
            sendResponse({ allowed: true, plan: 'FREE', remaining: FREE_LIMIT - (smUser.scanCount || 0) });
            return;
          }
          sendResponse({ allowed: false, reason: 'limit_reached', message: 'Free limit reached (10/10 scans used).' });
          return;
        }

        sendResponse({ allowed: false, reason: 'not_logged_in', message: 'Please sign in to your Siachen Mark account.' });
        break;
      }

      // ── 6. RECORD_USAGE ───────────────────────────────────
      case 'RECORD_USAGE': {
        const { smToken } = await chrome.storage.local.get(['smToken']);
        if (smToken) {
          try {
            const res = await fetch(`${API_BASE}/api/extension/verify`, {
              headers: { 'Authorization': `Bearer ${smToken}` },
            });
            if (res.ok) {
              const data = await res.json();
              await chrome.storage.local.set({ smUser: data.user });
              sendResponse({ success: true, user: data.user });
              break;
            }
          } catch (e) {}
        }
        sendResponse({ success: true });
        break;
      }

      // ── 7. SAVE_AUDIT / SAVE_SCAN ─────────────────────────
      case 'SAVE_AUDIT':
      case 'SAVE_SCAN': {
        const { smToken } = await chrome.storage.local.get(['smToken']);
        const audit = message.audit || message.scanData;

        if (!audit) {
          sendResponse({ success: false, message: 'No audit data provided.' });
          return;
        }

        // Format payload to match backend /api/extension/scan schema
        const payload = {
          businessName: audit.businessName || audit.name || 'Unknown Business',
          query: audit.rawData?.keyword || audit.query || 'Google Maps Audit',
          address: audit.rawData?.address || audit.address || '',
          phone: audit.rawData?.phone || audit.phone || '',
          website: audit.rawData?.website || audit.website || '',
          rating: audit.rawData?.rating ? parseFloat(audit.rawData.rating) : (audit.rating ? parseFloat(audit.rating) : 0),
          reviewCount: audit.rawData?.reviewCount ? parseInt(audit.rawData.reviewCount) : (audit.reviewCount ? parseInt(audit.reviewCount) : 0),
          score: audit.totalScore || audit.score || 0,
          grade: (audit.grade?.letter || audit.grade || 'C').toString(),
          issuesCount: audit.issues ? audit.issues.length : (audit.issuesCount || 0),
          data: audit,
        };

        // Add to local audit history
        const { auditHistory = [] } = await chrome.storage.local.get(['auditHistory']);
        auditHistory.unshift({
          id: 'local_' + Date.now(),
          businessName: payload.businessName,
          query: payload.query,
          address: payload.address,
          totalScore: payload.score,
          grade: payload.grade,
          auditDate: new Date().toISOString(),
          rawData: audit,
        });
        if (auditHistory.length > 100) auditHistory.splice(100);
        await chrome.storage.local.set({ auditHistory });

        // Send to backend if logged in
        if (smToken) {
          try {
            const res = await fetch(`${API_BASE}/api/extension/scan`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${smToken}`,
              },
              body: JSON.stringify(payload),
            });

            const data = await res.json();
            if (res.status === 403 && data.limitReached) {
              sendResponse({ success: false, limitReached: true, message: data.error });
              return;
            }
            if (res.ok) {
              // Update local scan count
              const { smUser } = await chrome.storage.local.get(['smUser']);
              if (smUser) {
                smUser.scanCount = (smUser.scanCount || 0) + 1;
                await chrome.storage.local.set({ smUser });
              }
              sendResponse({ success: true, report: data.report, remaining: data.remaining });
              return;
            }
          } catch (e) {
            console.warn('[SM SW] Backend sync error, saved locally:', e.message);
          }
        }

        sendResponse({ success: true, localOnly: true });
        break;
      }

      // ── 8. GET_HISTORY ────────────────────────────────────
      case 'GET_HISTORY': {
        const { auditHistory = [] } = await chrome.storage.local.get(['auditHistory']);
        sendResponse({ history: auditHistory });
        break;
      }

      // ── 9. DOWNLOAD_REPORT ────────────────────────────────
      case 'DOWNLOAD_REPORT': {
        try {
          const { filename, data, type } = message;
          const mimeType = type === 'html' ? 'text/html' : 'application/json';
          const contentStr = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
          const dataUrl = `data:${mimeType};charset=utf-8,` + encodeURIComponent(contentStr);

          await chrome.downloads.download({
            url: dataUrl,
            filename: filename || `report-${Date.now()}.${type || 'html'}`,
            saveAs: true,
          });

          sendResponse({ success: true });
        } catch (err) {
          console.error('[SM SW] Download error:', err);
          sendResponse({ success: false, message: err.message });
        }
        break;
      }

      // ── 10. VALIDATE_KEY (Legacy support) ─────────────────
      case 'VALIDATE_KEY': {
        const { key } = message;
        if (key === '571571') {
          const { smUser = {} } = await chrome.storage.local.get(['smUser']);
          const updatedUser = { ...(smUser || {}), plan: 'UNLIMITED' };
          await chrome.storage.local.set({ smUser: updatedUser });
          sendResponse({ success: true, message: 'Admin Unlimited Mode activated.' });
        } else {
          sendResponse({ success: false, message: 'Invalid key. Please sign in via email/password in the extension popup.' });
        }
        break;
      }

      default:
        sendResponse({ error: 'Unknown action: ' + message.action });
    }
  })();
  return true; // Keep message channel open for async response
});
