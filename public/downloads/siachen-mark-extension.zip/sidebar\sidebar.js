// ============================================================
// Siachen Mark — Sidebar JavaScript
// ============================================================

'use strict';

let allBusinesses  = [];
let allAudits      = [];
let currentBiz     = null;
let currentAudit   = null;
let tier           = 'free';
let usageCount     = 0;
let activeTab      = 'results';

// ── DOM refs ─────────────────────────────────────────────
const $ = id => document.getElementById(id);

// ── Init ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadLicenseStatus();
  setupTabs();
  setupLicensePanel();
  setupScanButton();
  setupModal();
  setupBulkDownload();
  loadHistory();

  // Listen for scrape progress from content script
  chrome.runtime.onMessage.addListener(handleRuntimeMessage);
});

// ── Load License Status ───────────────────────────────────
async function loadLicenseStatus() {
  const res = await sendBG({ action: 'GET_LICENSE' });

  tier = res.tier || 'free';
  usageCount = res.usageCount || 0;

  // Show banner
  $('license-banner').classList.remove('hidden');
  $('tier-free').classList.add('hidden');
  $('tier-paid').classList.add('hidden');
  $('tier-admin').classList.add('hidden');

  if (tier === 'admin') {
    $('tier-admin').classList.remove('hidden');
    $('pro-hint').classList.remove('hidden');
  } else if (tier === 'paid') {
    $('tier-paid').classList.remove('hidden');
    $('days-left').textContent = res.daysLeft || '?';
    $('pro-hint').classList.remove('hidden');
    if (res.expired) showLicenseMsg('Your Pro key has expired. Please get a new key.', 'error');
  } else {
    $('tier-free').classList.remove('hidden');
    $('usage-count').textContent = usageCount;
    $('free-hint').classList.remove('hidden');
  }
}

// ── Setup License Panel ───────────────────────────────────
function setupLicensePanel() {
  $('btn-license').addEventListener('click', () => {
    $('license-panel').classList.toggle('hidden');
  });

  $('btn-activate').addEventListener('click', async () => {
    const key = $('license-input').value.trim();
    if (!key) return;

    $('btn-activate').textContent = '...';
    $('btn-activate').disabled = true;

    const res = await sendBG({ action: 'VALIDATE_KEY', key });

    if (res.success) {
      showLicenseMsg('✅ ' + res.message, 'success');
      await loadLicenseStatus();
    } else {
      showLicenseMsg('❌ ' + res.message, 'error');
    }

    $('btn-activate').textContent = 'Activate';
    $('btn-activate').disabled = false;
  });

  $('license-input').addEventListener('keypress', e => {
    if (e.key === 'Enter') $('btn-activate').click();
  });
}

function showLicenseMsg(msg, type) {
  const el = $('license-msg');
  el.textContent = msg;
  el.className = `license-msg ${type}`;
  el.classList.remove('hidden');
  if (type === 'success') setTimeout(() => el.classList.add('hidden'), 4000);
}

// ── Setup Tabs ────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      activeTab = btn.dataset.tab;
      $('tab-' + activeTab).classList.add('active');
      if (activeTab === 'ranking') renderRanking();
      if (activeTab === 'history') loadHistory();
    });
  });
}

// ── Setup Scan Button ─────────────────────────────────────
function setupScanButton() {
  $('btn-scan').addEventListener('click', startScan);
  $('keyword-input').addEventListener('keypress', e => {
    if (e.key === 'Enter') startScan();
  });
}

async function startScan() {
  const keyword = $('keyword-input').value.trim();
  if (!keyword) {
    $('keyword-input').focus();
    return;
  }

  // Check limit
  const limitRes = await sendBG({ action: 'CHECK_LIMIT' });
  if (!limitRes || !limitRes.allowed) {
    if (limitRes?.reason === 'not_logged_in') {
      showAlert('🔒 Please sign in to your Siachen Mark account first.\nClick the extension icon in Chrome toolbar to log in.');
    } else if (limitRes?.reason === 'limit_reached') {
      showAlert('🚫 Free plan limit reached (10/10 scans used).\nUpgrade to Unlimited plan to continue auditing.');
    } else {
      showAlert('⚠️ ' + (limitRes?.message || 'Scan not allowed. Please check your account status.'));
    }
    return;
  }

  const limit = (tier === 'admin' || limitRes?.plan === 'UNLIMITED') ? 50 : 10;

  // Check if on Google Maps
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab.url || !tab.url.includes('google.com/maps')) {
    showAlert('⚠️ Please open Google Maps first and search for your keyword!');
    return;
  }

  // Reset
  allBusinesses = [];
  allAudits = [];
  $('results-list').innerHTML = '';
  $('results-list').classList.add('hidden');
  $('results-empty').classList.add('hidden');
  $('bulk-actions').classList.add('hidden');
  $('tab-results').classList.add('active');

  // Show progress
  $('progress-section').classList.remove('hidden');
  $('progress-text').textContent = `Scanning "${keyword}"...`;
  $('progress-count').textContent = '0/?';
  $('progress-bar').style.width = '0%';

  // Disable scan button
  $('btn-scan').disabled = true;
  $('scan-label').textContent = 'Scanning...';

  // Inject and run scraper
  try {
    // Ping content script
    let contentReady = false;
    try {
      const ping = await chrome.tabs.sendMessage(tab.id, { action: 'PING' });
      contentReady = ping?.pong;
    } catch (e) {
      // Inject if not ready
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/maps-scraper.js'] });
      await sleep(500);
    }

    // P0 FIX #2: ITEMISED MESSAGING & SEQUENTIAL PROCESSING
    const listRes = await chrome.tabs.sendMessage(tab.id, {
      action: 'GET_BUSINESS_LIST',
      limit
    });

    if (listRes && listRes.success && listRes.businesses && listRes.businesses.length > 0) {
      const basicList = listRes.businesses;
      $('results-list').classList.remove('hidden');
      $('results-list').innerHTML = '';

      for (let i = 0; i < basicList.length; i++) {
        const basic = basicList[i];

        // Update progress UI
        $('progress-text').textContent = `Auditing (${i + 1}/${basicList.length}): ${basic.name}`;
        $('progress-count').textContent = `${i + 1}/${basicList.length}`;
        $('progress-bar').style.width = `${Math.round(((i + 1) / basicList.length) * 100)}%`;

        let businessData = null;
        try {
          const extractRes = await chrome.tabs.sendMessage(tab.id, {
            action: 'EXTRACT_SINGLE_BUSINESS',
            index: i
          });
          if (extractRes && extractRes.success && extractRes.businessData) {
            businessData = extractRes.businessData;
          } else {
            console.warn(`[SM Sidebar] Skipping item ${i} (${basic.name}) - Full profile did not open:`, extractRes?.error || extractRes?.message);
            await chrome.tabs.sendMessage(tab.id, { action: 'RETURN_TO_RESULTS' }).catch(() => {});
            continue;
          }
        } catch (err) {
          console.warn(`[SM Sidebar] Message error for item ${i}:`, err);
          await chrome.tabs.sendMessage(tab.id, { action: 'RETURN_TO_RESULTS' }).catch(() => {});
          continue;
        }

        // Run local audit engine
        const audit = runGBPAudit(businessData);
        allBusinesses.push(businessData);
        allAudits.push(audit);

        // Save audit sequentially (no parallel burst)
        const saveRes = await sendBG({ action: 'SAVE_AUDIT', audit: { ...audit, businessData } });
        
        // Render card
        const card = createResultCard(businessData, audit, allBusinesses.length - 1);
        $('results-list').appendChild(card);
        renderRanking();
        $('bulk-actions').classList.remove('hidden');

        // Check if free plan limit reached
        if (saveRes && saveRes.limitReached) {
          showAlert('🚫 Free plan limit reached (10/10 scans used).\nUpgrade to Unlimited plan to continue auditing.');
          break; // Gracefully stop batch scan
        }

        // Return to search results before auditing next business
        if (i < basicList.length - 1) {
          $('progress-text').textContent = `Returning to search results...`;
          const returnRes = await chrome.tabs.sendMessage(tab.id, { action: 'RETURN_TO_RESULTS' });
          if (!returnRes || !returnRes.success) {
            console.error(`[SM Sidebar] Could not return to search results after item ${i + 1}. Halting batch.`);
            showAlert(`⚠️ Could not return to search results feed after auditing "${basic.name}". Batch audit stopped.`);
            break;
          }
          await sleep(500); // Allow search feed stabilization
        }
      }

      await sendBG({ action: 'RECORD_USAGE' });
      await loadLicenseStatus();

    } else {
      showNoResults();
    }

  } catch (err) {
    console.error('[SM Sidebar] Scan error:', err);
    showNoResults('Error scanning. Make sure you are on Google Maps with search results visible.');
  }

  // Re-enable
  $('btn-scan').disabled = false;
  $('scan-label').textContent = 'Scan';
  $('progress-section').classList.add('hidden');
}



// ── Create Result Card ────────────────────────────────────
function createResultCard(biz, audit, idx) {
  const scoreColor = getScoreColor(audit.totalScore);
  const card = document.createElement('div');
  card.className = 'result-card fade-in';
  card.dataset.idx = idx;

  const topCategories = ['name', 'reviews', 'photos', 'hours', 'website'];
  const miniBars = topCategories.map(key => {
    const s = audit.scores[key];
    if (!s) return '';
    const pct = Math.round((s.earned / s.max) * 100);
    const color = pct >= 70 ? '#10B981' : pct >= 40 ? '#F59E0B' : '#EF4444';
    return `<div class="mini-bar-row">
      <span class="mini-bar-label">${s.name.split(' ')[0]}</span>
      <div class="mini-bar-bg"><div class="mini-bar-fill" style="width:${pct}%;background:${color}"></div></div>
      <span class="mini-bar-val">${s.earned}/${s.max}</span>
    </div>`;
  }).join('');

  card.innerHTML = `
    <div class="result-card-header">
      <div class="result-pos">${biz.position || idx + 1}</div>
      <div class="result-name">${biz.name || 'Unknown'}</div>
      <div class="result-score-circle" style="color:${scoreColor}">
        <span>${audit.totalScore}</span>
        <span style="font-size:9px;font-weight:400;color:${scoreColor}80">/100</span>
      </div>
    </div>
    <div class="result-meta">
      ${biz.rating ? `<span class="meta-chip">★ ${biz.rating} (${biz.reviewCount || 0})</span>` : ''}
      ${biz.primaryCategory ? `<span class="meta-chip">📍 ${biz.primaryCategory}</span>` : ''}
      ${biz.phone ? `<span class="meta-chip">📞 ${biz.phone}</span>` : '<span class="meta-chip" style="color:#EF4444">📞 No Phone</span>'}
      ${biz.website ? `<span class="meta-chip">🌐 Website</span>` : '<span class="meta-chip" style="color:#EF4444">🌐 No Website</span>'}
    </div>
    <div class="result-mini-bars">${miniBars}</div>
    <div class="result-issues">
      ${audit.issues.length > 0 ? `<span class="issue-chip chip-error">🔴 ${audit.issues.length} Issues</span>` : ''}
      ${audit.warnings.length > 0 ? `<span class="issue-chip chip-warning">⚠️ ${audit.warnings.length} Warnings</span>` : ''}
      ${audit.passed.length > 0 ? `<span class="issue-chip chip-success">✅ ${audit.passed.length} Passed</span>` : ''}
    </div>
    <div class="result-actions">
      <button class="btn-sm primary btn-detail" data-idx="${idx}">📋 Full Audit</button>
      <button class="btn-sm btn-dl-html" data-idx="${idx}">⬇ HTML</button>
      <button class="btn-sm btn-dl-json" data-idx="${idx}">⬇ JSON</button>
    </div>`;

  // Event listeners
  card.querySelector('.btn-detail').addEventListener('click', e => {
    e.stopPropagation();
    openDetailModal(idx);
  });
  card.querySelector('.btn-dl-html').addEventListener('click', e => {
    e.stopPropagation();
    downloadReport(idx, 'html');
  });
  card.querySelector('.btn-dl-json').addEventListener('click', e => {
    e.stopPropagation();
    downloadReport(idx, 'json');
  });
  card.addEventListener('click', () => openDetailModal(idx));

  return card;
}

// ── Open Detail Modal ─────────────────────────────────────
function openDetailModal(idx) {
  currentBiz = allBusinesses[idx];
  currentAudit = allAudits[idx];

  $('modal-biz-name').textContent = currentAudit.businessName;

  const scoreColor = getScoreColor(currentAudit.totalScore);
  const grade = currentAudit.grade;

  let html = `
    <div class="detail-score-row">
      <div class="detail-circle" style="color:${scoreColor};border-color:${scoreColor}">
        ${currentAudit.totalScore}
      </div>
      <div>
        <div class="detail-grade" style="color:${grade.color}">${grade.letter}</div>
        <div class="detail-grade-label">${grade.label}</div>
      </div>
      <div class="detail-counts">
        <span style="color:#EF4444">🔴 ${currentAudit.issues.length} Issues</span>
        <span style="color:#F59E0B">⚠️ ${currentAudit.warnings.length} Warnings</span>
        <span style="color:#10B981">✅ ${currentAudit.passed.length} Passed</span>
      </div>
    </div>

    <div class="detail-section">
      <div class="detail-section-title">📊 Score Breakdown</div>
      ${Object.entries(currentAudit.scores).map(([k, s]) => {
        const pct = Math.round((s.earned / s.max) * 100);
        const color = pct >= 70 ? '#10B981' : pct >= 40 ? '#F59E0B' : '#EF4444';
        return `<div class="detail-bar-row">
          <span class="detail-bar-label">${s.name}</span>
          <div class="detail-bar-bg"><div class="detail-bar-fill" style="width:${pct}%;background:${color}"></div></div>
          <span class="detail-bar-pts">${s.earned}/${s.max}</span>
        </div>`;
      }).join('')}
    </div>`;

  if (currentAudit.issues.length > 0) {
    html += `<div class="detail-section">
      <div class="detail-section-title">🔴 Issues to Fix</div>
      ${currentAudit.issues.map(i => `
        <div class="detail-issue ${i.severity}">
          <span>${i.severity === 'critical' ? '🔴' : i.severity === 'high' ? '🟠' : '🟡'}</span>
          <div><strong>${i.category}</strong><br>${i.message}</div>
        </div>`).join('')}
    </div>`;
  }

  if (currentAudit.warnings.length > 0) {
    html += `<div class="detail-section">
      <div class="detail-section-title">⚠️ Warnings</div>
      ${currentAudit.warnings.map(w => `
        <div class="detail-warning">⚠️ <div><strong>${w.category}</strong><br>${w.message}</div></div>`).join('')}
    </div>`;
  }

  if (currentAudit.passed.length > 0) {
    html += `<div class="detail-section">
      <div class="detail-section-title">✅ Passed</div>
      ${currentAudit.passed.map(p => `<div class="detail-pass">✅ ${p}</div>`).join('')}
    </div>`;
  }

  html += `<div class="detail-section">
    <div class="detail-section-title">📈 Ranking Factors</div>
    ${currentAudit.rankingFactors.map(rf => {
      const statusColors = {
        'Strong': '#10B981', 'Good': '#10B981', 'Set': '#10B981', 'Complete': '#10B981', 'Active': '#10B981', 'Linked': '#10B981',
        'Moderate': '#F59E0B', 'Present': '#F59E0B',
        'Weak': '#EF4444', 'Missing': '#EF4444', 'Stale': '#EF4444', 'Low': '#F59E0B', 'Incomplete': '#EF4444', 'Needs Work': '#EF4444'
      };
      const sc = statusColors[rf.status] || '#64748B';
      return `<div class="rank-factor-row">
        <div style="flex:1">
          <div class="rf-name">${rf.factor}</div>
          <div class="rf-tip">${rf.tip}</div>
        </div>
        <div>
          <div class="rf-status" style="background:${sc}20;color:${sc};border:1px solid ${sc}40">${rf.status}</div>
          <div style="font-size:9px;color:#64748B;text-align:center;margin-top:2px">${rf.importance}</div>
        </div>
      </div>`;
    }).join('')}
  </div>`;

  $('modal-body').innerHTML = html;
  $('detail-modal').classList.remove('hidden');
}

// ── Modal Events ──────────────────────────────────────────
function setupModal() {
  $('modal-close').addEventListener('click', closeModal);
  $('modal-backdrop').addEventListener('click', closeModal);

  $('modal-dl-html').addEventListener('click', () => {
    if (currentBiz && currentAudit) downloadReportDirect(currentBiz, currentAudit, 'html');
  });
  $('modal-dl-json').addEventListener('click', () => {
    if (currentBiz && currentAudit) downloadReportDirect(currentBiz, currentAudit, 'json');
  });
}

function closeModal() {
  $('detail-modal').classList.add('hidden');
}

// ── Download Report ───────────────────────────────────────
function downloadReport(idx, type) {
  downloadReportDirect(allBusinesses[idx], allAudits[idx], type);
}

function downloadReportDirect(biz, audit, type) {
  const safeName = sanitizeFilename(audit.businessName);
  const filename = `siachen-mark-${safeName}-${Date.now()}.${type === 'html' ? 'html' : 'json'}`;

  if (type === 'html') {
    const html = generateHTMLReport(biz, audit);
    sendBG({ action: 'DOWNLOAD_REPORT', filename, data: html, type: 'html' });
  } else {
    const json = generateJSONReport(biz, audit);
    sendBG({ action: 'DOWNLOAD_REPORT', filename, data: json, type: 'json' });
  }
}

// ── Bulk Download ─────────────────────────────────────────
function setupBulkDownload() {
  $('btn-download-all-json').addEventListener('click', async () => {
    const allReports = allBusinesses.map((biz, i) => generateJSONReport(biz, allAudits[i]));
    const combined = { tool: 'Siachen Mark', generatedAt: new Date().toISOString(), totalBusinesses: allReports.length, reports: allReports };
    sendBG({ action: 'DOWNLOAD_REPORT', filename: `siachen-mark-bulk-${Date.now()}.json`, data: combined, type: 'json' });
  });

  $('btn-download-all-html').addEventListener('click', async () => {
    allBusinesses.forEach((biz, i) => {
      setTimeout(() => {
        const html = generateHTMLReport(biz, allAudits[i]);
        const safeName = sanitizeFilename(allAudits[i].businessName);
        sendBG({ action: 'DOWNLOAD_REPORT', filename: `siachen-mark-${safeName}.html`, data: html, type: 'html' });
      }, i * 300);
    });
  });
}

// ── Ranking Table ─────────────────────────────────────────
function renderRanking() {
  if (allAudits.length === 0) {
    $('ranking-empty').classList.remove('hidden');
    $('ranking-table').classList.add('hidden');
    return;
  }

  $('ranking-empty').classList.add('hidden');
  $('ranking-table').classList.remove('hidden');

  const sorted = [...allAudits].map((a, i) => ({ ...a, originalIdx: i }))
    .sort((a, b) => b.totalScore - a.totalScore);

  $('ranking-table').innerHTML = `
    <table class="rank-table">
      <thead>
        <tr>
          <th>Rank</th>
          <th>Business</th>
          <th>Score</th>
          <th>Rating</th>
          <th>Issues</th>
        </tr>
      </thead>
      <tbody>
        ${sorted.map((audit, rank) => {
          const biz = allBusinesses[audit.originalIdx];
          const sc = getScoreColor(audit.totalScore);
          return `<tr>
            <td style="font-weight:700;color:${rank === 0 ? '#F59E0B' : '#94A3B8'}">#${rank + 1}</td>
            <td style="color:#E2E8F0;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${audit.businessName}</td>
            <td><span style="font-weight:700;color:${sc}">${audit.totalScore}</span></td>
            <td>${biz.rating || '—'} ★</td>
            <td><span style="color:#EF4444">🔴${audit.issues.length}</span> <span style="color:#F59E0B">⚠${audit.warnings.length}</span></td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>`;
}

// ── History ───────────────────────────────────────────────
async function loadHistory() {
  const res = await sendBG({ action: 'GET_HISTORY' });
  const history = res.history || [];

  if (history.length === 0) {
    $('history-empty').classList.remove('hidden');
    $('history-list').classList.add('hidden');
    return;
  }

  $('history-empty').classList.add('hidden');
  $('history-list').classList.remove('hidden');
  $('history-list').innerHTML = '';

  history.slice(0, 30).forEach(item => {
    const sc = getScoreColor(item.totalScore);
    const div = document.createElement('div');
    div.className = 'history-item';
    div.innerHTML = `
      <div class="history-name">${item.businessName}</div>
      <div class="history-date">${new Date(item.auditDate).toLocaleDateString()}</div>
      <div class="history-score" style="color:${sc}">${item.totalScore}/100</div>`;
    $('history-list').appendChild(div);
  });
}

// ── Runtime Message Handler ───────────────────────────────
function handleRuntimeMessage(message) {
  if (message.action === 'SCRAPE_PROGRESS') {
    const pct = message.total > 0 ? Math.round((message.current / message.total) * 100) : 0;
    $('progress-bar').style.width = pct + '%';
    $('progress-count').textContent = `${message.current}/${message.total}`;
    if (message.business?.name) {
      $('progress-text').textContent = `Scanning: ${message.business.name}`;
    }
  }
}

// ── Show Alert ────────────────────────────────────────────
function showAlert(msg) {
  alert(msg);
}

function showNoResults(msg) {
  $('results-empty').classList.remove('hidden');
  $('results-empty').querySelector('.empty-desc').textContent =
    msg || 'No business results found. Make sure you are on a Google Maps search page.';
}

// ── Helpers ───────────────────────────────────────────────
function getScoreColor(score) {
  if (score >= 80) return '#10B981';
  if (score >= 65) return '#F59E0B';
  if (score >= 50) return '#F97316';
  return '#EF4444';
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function sendBG(message) {
  return chrome.runtime.sendMessage(message);
}
